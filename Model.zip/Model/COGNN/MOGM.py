import torch
import torch.nn as nn
import torch.nn.functional as F


class ElementScale(nn.Module):
    def __init__(self, embed_dims, init_value=0., requires_grad=True):
        super(ElementScale, self).__init__()
        self.scale = nn.Parameter(
            init_value * torch.ones((embed_dims, 1, 1)),
            requires_grad=requires_grad
        )

    def forward(self, x):
        return x * self.scale


class MOGM(nn.Module):
    def __init__(self, embed_dims, out_channels):
        super(MOGM, self).__init__()
        self.embed_dims = embed_dims
        self.out_channels = out_channels

        # 第一分支：1x1卷积 + Sigmoid
        self.branch_1 = nn.Sequential(
            nn.Conv2d(embed_dims, embed_dims, kernel_size=1),
            nn.Sigmoid()
        )

        # 第二分支：按通道分割后分别进行卷积
        split_ratios = [3 / 8, 1 / 8, 1 / 2]  # 通道分割比例
        self.split_dims = [
            int(embed_dims * split_ratios[0]),
            int(embed_dims * split_ratios[1]),
            embed_dims - int(embed_dims * split_ratios[0]) - int(embed_dims * split_ratios[1])  # 保证总和为 embed_dims
        ]

        self.conv_5x5 = nn.Conv2d(
            in_channels=self.split_dims[0],
            out_channels=self.split_dims[0],
            kernel_size=5,
            padding=2,  # 保持空间大小不变
            groups=self.split_dims[0]
        )

        self.conv_7x7 = nn.Conv2d(
            in_channels=self.split_dims[2],
            out_channels=self.split_dims[2],
            kernel_size=7,
            padding=3,  # 保持空间大小不变
            groups=self.split_dims[2]
        )

        self.linear_cat = nn.Conv2d(
            in_channels=embed_dims,
            out_channels=embed_dims,  # 使用传入的 out_channels 控制输出通道数
            kernel_size=1
        )

        self.linear_out = nn.Conv2d(
            in_channels=embed_dims,
            out_channels=out_channels,  # 使用传入的 out_channels 控制输出通道数
            kernel_size=1
        )

    def forward(self, x):
        # 添加批次维度（暂时）
        if x.ndim == 3:  # 输入 [C, H, W]
            x = x.unsqueeze(0)  # 转为 [1, C, H, W]

        # 第一分支
        branch_1_out = self.branch_1(x)

        # 第二分支：通道分割并卷积
        cumsum_split = [0] + torch.cumsum(torch.tensor(self.split_dims), dim=0).tolist()
        x_split_1 = x[:, cumsum_split[0]:cumsum_split[1], :, :]  # 3/8 通道部分
        x_split_2 = x[:, cumsum_split[1]:cumsum_split[2], :, :]  # 1/8 通道部分
        x_split_3 = x[:, cumsum_split[2]:cumsum_split[3], :, :]  # 1/2 通道部分

        x_split_1_out = self.conv_5x5(x_split_1)
        x_split_3_out = self.conv_7x7(x_split_3)

        # 合并并线性变换
        merged = torch.cat([x_split_1_out, x_split_2, x_split_3_out], dim=1)
        branch_2_out = self.linear_cat(merged)

        # 分支点乘
        out = branch_1_out * branch_2_out
        out = self.linear_out(out)

        # 去掉批次维度
        if out.size(0) == 1:
            out = out.squeeze(0)  # 转回 [C, H, W]

        return out


if __name__ == '__main__':
    input_tensor = torch.randn(64, 32, 32)  # 输入：通道数64，高32，宽32
    mogm_block = MOGM(embed_dims=64, out_channels=32)  # 输出通道设为 32
    output_tensor = mogm_block(input_tensor)
    print("输入大小:", input_tensor.size())
    print("输出大小:", output_tensor.size())
