from typing import Callable
import torch
from torch import Tensor
from torch.nn import Linear, ReLU, BatchNorm1d, Module, Sigmoid

from torch_geometric.nn.conv import MessagePassing
from torch_geometric.nn.conv.gcn_conv import gcn_norm
from torch_geometric.typing import NoneType  # noqa
from torch_geometric.typing import (
    Adj,
    OptTensor,
)
from torch_geometric.utils import remove_self_loops, add_remaining_self_loops


def get_virtualnode_mlp(emb_dim: int) -> Module:
    return torch.nn.Sequential(Linear(emb_dim, 2 * emb_dim), BatchNorm1d(2 * emb_dim), ReLU(),
                               Linear(2 * emb_dim, emb_dim), BatchNorm1d(emb_dim), ReLU())


# 对单个节点特征，边特征以及边权重信息聚合的类 边特征向量与节点特征向量维度一致
# 继承自MessagePassing类 核心步骤为 消息传递 信息聚合 节点更新
# class MolConv(MessagePassing):
    # def message(self, x_j: Tensor, edge_attr: OptTensor, edge_weight: OptTensor = None) -> Tensor:
        # if edge_attr is None:
            # if edge_weight is None:
                # return x_j
            # else:
                # return edge_weight.view(-1, 1) * x_j
        # else:
            # if edge_weight is None:
                # return x_j + edge_attr
            # else:
                # return edge_weight.view(-1, 1) * (x_j + edge_attr)

    # def update(self, aggr_out):
        # return aggr_out
# # 消息传递类，继承自 MessagePassing
# class MolConv(MessagePassing):
#     def __init__(self, **kwargs):
#         super().__init__(**kwargs)
#
#     # 处理消息传递的逻辑，支持 edge_attr 和 edge_weight
#     def message(self, x_j: Tensor, edge_attr: OptTensor, edge_weight: OptTensor = None) -> Tensor:
#         if edge_attr is None:
#             if edge_weight is None:
#                 return x_j
#             else:
#                 return edge_weight.view(-1, 1) * x_j
#         else:
#             if edge_weight is None:
#                 return x_j + edge_attr
#             else:
#                 return edge_weight.view(-1, 1) * (x_j + edge_attr)
#
#     # 节点更新
#     def update(self, aggr_out):
#         return aggr_out
#
# # 自定义 propagate 函数，确保支持 edge_attr
#     def propagate(self, edge_index, x=None, edge_weight=None, edge_attr=None, size=None):
#         # 调用父类的 propagate 并传递 edge_attr
#         return super().propagate(edge_index=edge_index, x=x, edge_weight=edge_weight, size=size, edge_attr=edge_attr)

class MolConv(MessagePassing):
    def __init__(self, aggr='add'):
        super().__init__(aggr=aggr)  # 'add', 'mean' or 'max'

    def message(self, x_j: Tensor, edge_attr: OptTensor, edge_weight: OptTensor = None) -> Tensor:

        if edge_attr is None:
            if edge_weight is None:
                return x_j
            else:
                return edge_weight.view(-1, 1) * x_j
        else:
            if edge_weight is None:
                return x_j + edge_attr
            else:
                return edge_weight.view(-1, 1) * (x_j + edge_attr)

    def update(self, aggr_out: Tensor) -> Tensor:

        return aggr_out

class WeightedGCNConv(MolConv):
    def __init__(self, in_channels: int, out_channels: int, bias: bool, **kwargs):
        kwargs.setdefault('aggr', 'add')
        # 这里设定消息的聚合方式是add 加权聚合 还有mean max 和 min
        super().__init__(**kwargs)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.add_self_loops = True
        self.improved = False

        self.lin = Linear(in_channels, out_channels, bias=bias)

    def forward(self, x: Tensor, edge_index: Adj, edge_attr: OptTensor = None, edge_weight: OptTensor = None) -> Tensor:
        edge_index = remove_self_loops(edge_index=edge_index)[0]
        _, edge_attr = add_remaining_self_loops(edge_index, edge_attr, fill_value=1, num_nodes=x.shape[0])
        # 去点自连接再根据设定进行重新连接

        # propagate_type: (x: Tensor, edge_weight: OptTensor)
        edge_index, edge_weight = gcn_norm(  # yapf: disable
            edge_index, edge_weight, x.size(self.node_dim),
            self.improved, self.add_self_loops, self.flow, x.dtype)
        out = self.propagate(edge_index, x=x, edge_weight=edge_weight, size=None, edge_attr=edge_attr)
        out = self.lin(out)
        return out


# GIN convolution along the graph structure
class WeightedGINConv(MolConv):
    def __init__(self, in_channels: int, out_channels: int, bias: bool, mlp_func: Callable):
        """
            emb_dim (int): node embedding dimensionality
        """
        super(WeightedGINConv, self).__init__(aggr="add")

        self.mlp = mlp_func(in_channels=in_channels, out_channels=out_channels, bias=bias)
        self.eps = torch.Tensor([0])
        self.eps = torch.nn.Parameter(self.eps)

    def forward(self, x: Tensor, edge_index: Adj, edge_attr: OptTensor = None, edge_weight: OptTensor = None) -> Tensor:
        out = self.propagate(edge_index, x=x, edge_weight=edge_weight, size=None, edge_attr=edge_attr)

        return self.mlp((1 + self.eps.to(x.device)) * x + out)

class WeightedGNNConv(MolConv):
    def __init__(self, in_channels: int, out_channels: int, aggr='add', bias=True):
        super().__init__(aggr=aggr)
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.lin = Linear(2 * in_channels, out_channels, bias=bias)

    def forward(self, x: Tensor, edge_index: Adj, edge_attr: OptTensor = None, edge_weight: OptTensor = None) -> Tensor:
        out = self.propagate(edge_index, x=x, edge_attr=edge_attr, edge_weight=edge_weight)
        out = self.lin(torch.cat((x, out), dim=-1))
        return out

class GatedGCNConv(MolConv):
    def __init__(self, in_channels: int, out_channels: int, aggr='add', bias=True):
        super().__init__(aggr=aggr)
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.lin = Linear(in_channels, out_channels, bias=bias)
        self.sigmoid = torch.nn.Sigmoid()

    def forward(self, x: Tensor, edge_index: Adj, edge_attr: OptTensor = None, edge_weight: OptTensor = None) -> Tensor:
        out = self.propagate(edge_index, x=x, edge_attr=edge_attr, edge_weight=edge_weight)
        gating = self.sigmoid(self.lin(x))

        out = out * gating
        return out
# 上边那个是标准的GCN任务，依赖于GCN标准的归一化
# 提供了更多的灵活性，尤其是将节点自身特征与邻居特征拼接的机制，适用于需要保留节点自身信息并结合邻居信息的场景
# class WeightedGNNConv(MolConv):
#     def __init__(self, in_channels: int, out_channels: int, aggr: str, bias: bool, **kwargs):
#         kwargs.setdefault('aggr', aggr)
#         # 可选 更加灵活 add mean max min
#         super().__init__(**kwargs)
#
#         self.in_channels = in_channels
#         self.out_channels = out_channels
#         self.lin = Linear(2 * in_channels, out_channels, bias=bias)
#
#     def forward(self, x: Tensor, edge_index: Adj, edge_attr: OptTensor = None, edge_weight: OptTensor = None) -> Tensor:
#         # propagate_type: (x: Tensor, edge_weight: OptTensor)
#         out = self.propagate(edge_index, x=x, edge_weight=edge_weight, size=None, edge_attr=edge_attr)
#         out = self.lin(torch.cat((x, out), dim=-1))
#         return out


class GraphLinear(Linear):
    def forward(self, x: Tensor, edge_index: Adj, edge_attr: OptTensor = None, edge_weight: OptTensor = None) -> Tensor:
        return super().forward(x)
