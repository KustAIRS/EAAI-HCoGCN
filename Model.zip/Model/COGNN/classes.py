from enum import Enum, auto
from torch.nn import Linear, ModuleList, Module, ReLU, GELU
from torch import Tensor
from typing import NamedTuple, Any, Callable
import torch.nn.functional as F
from torch_geometric.nn.pool import global_mean_pool, global_add_pool
from Model.COGNN.model import ModelType
import torch


class ActivationType(Enum):
    """
        an object for the different activation types
    """
    RELU = auto()
    GELU = auto() 

    @staticmethod
    def from_string(s: str):  
        try:
            return ActivationType[s]
        except KeyError:
            raise ValueError()

    def get(self):
        if self is ActivationType.RELU:
            return F.relu
        elif self is ActivationType.GELU:
            return F.gelu
        else:
            raise ValueError(f'ActivationType {self.name} not supported')

    def nn(self) -> Module:
        if self is ActivationType.RELU:
            return ReLU()
        elif self is ActivationType.GELU:
            return GELU()
        else:
            raise ValueError(f'ActivationType {self.name} not supported')

def gin_mlp_func(self) -> Callable:

    def mlp_func(in_channels: int, out_channels: int, bias: bool):
        return torch.nn.Sequential(torch.nn.Linear(in_channels, out_channels, bias=bias),
                                        torch.nn.ReLU(), torch.nn.Linear(out_channels, out_channels, bias=bias))


    return mlp_func


class GumbelArgs(NamedTuple):   
    learn_temp: bool  
    temp_model_type: ModelType 
    tau0: float             
    temp: float             
    gin_mlp_func: Callable  


class Pool(Enum):
    """
        an object for the different activation types
    """
    NONE = auto()
    MEAN = auto()
    SUM = auto()

    @staticmethod
    def from_string(s: str):
        try:
            return Pool[s]
        except KeyError:
            raise ValueError()

    def get(self):
        if self is Pool.MEAN:
            return global_mean_pool  
        elif self is Pool.SUM:
            return global_add_pool   
        elif self is Pool.NONE:
            return BatchIdentity()   
        else:
            raise ValueError(f'Pool {self.name} not supported')

# 编码 特征提取 解码
class EnvArgs(NamedTuple):
    model_type: ModelType
    num_layers: int
    env_dim: int

    layer_norm: bool
    skip: bool
    batch_norm: bool
    dropout: float
    act_type: ActivationType

    in_dim: int
    out_dim: int

    gin_mlp_func: Callable


    def load_net(self) -> ModuleList:

        enc_list = [Linear(self.in_dim, self.env_dim)]

        component_list =\
            self.model_type.get_component_list(in_dim=self.env_dim, hidden_dim=self.env_dim,  out_dim=self.env_dim,
                                               num_layers=self.num_layers, bias=True, edges_required=True,
                                               gin_mlp_func=self.gin_mlp_func)
        dec_list = [Linear(self.env_dim, self.out_dim)]

        return ModuleList(enc_list + component_list + dec_list)


class ActionNetArgs(NamedTuple):
    # in_dim: int
    model_type: ModelType
    num_layers: int
    hidden_dim: int

    dropout: float
    act_type: ActivationType

    env_dim: int
    gin_mlp_func: Callable
    
    def load_net(self) -> ModuleList:
        net = self.model_type.get_component_list(in_dim=self.env_dim, hidden_dim=self.hidden_dim, out_dim=2,
                                                 num_layers=self.num_layers, bias=True, edges_required=False,
                                                 gin_mlp_func=self.gin_mlp_func)
        return ModuleList(net)

class BatchIdentity(Module):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__()

    def forward(self, x: Tensor, batch: Tensor) -> Tensor:
        return x
