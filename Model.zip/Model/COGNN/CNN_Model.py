import torch
import torch.nn as nn
import torch.nn.functional as F
import pdb
from functools import partial
import torch
import torch.nn as nn
import torch.nn.functional as F
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class SSConv(nn.Module):  

    def __init__(self, in_ch, out_ch, kernel_size=3):  # (batch_size, in_ch, height, width)
        super(SSConv, self).__init__()
        self.depth_conv = nn.Conv2d(  # (batch_size, out_ch, height, width)
            in_channels=out_ch,
            out_channels=out_ch,
            kernel_size=kernel_size,
            stride=1,
            padding=kernel_size // 2,
            groups=out_ch
        )
        self.point_conv = nn.Conv2d(  # (batch_size, out_ch, height, width)  1*1卷积核
            in_channels=in_ch,
            out_channels=out_ch,
            kernel_size=1,
            stride=1,
            padding=0,
            groups=1,
            bias=False
        )
        # self.denoise = nn.Conv2d(in_channels=in_ch, out_channels=32, kernel_size=(1, 1))
        self.Act1 = nn.LeakyReLU()
        self.Act2 = nn.LeakyReLU()
        self.BN = nn.BatchNorm2d(in_ch)

    def forward(self, input):
        out = self.point_conv(self.BN(input))
        # pdb.set_trace()
        out = self.Act1(out)
        out = self.depth_conv(out)
        out = self.Act2(out)
        return out

class CNN(nn.Module):
    def __init__(self, in_changel: int,out_changel: int):
        super(CNN, self).__init__()
        self.channel = in_changel
        self.out_channel = out_changel

        layers_count=2


        self.WH = 0
        self.M = 2
        self.CNN_denoise = nn.Sequential()
        for i in range(layers_count):
            if i == 0:
                self.CNN_denoise.add_module('CNN_denoise_BN'+str(i),nn.BatchNorm2d(self.channel))
                self.CNN_denoise.add_module('CNN_denoise_Conv'+str(i),nn.Conv2d(self.channel, 128, kernel_size=(1, 1)))
                self.CNN_denoise.add_module('CNN_denoise_Act'+str(i),nn.LeakyReLU())
            else:
                self.CNN_denoise.add_module('CNN_denoise_BN'+str(i),nn.BatchNorm2d(128),)
                self.CNN_denoise.add_module('CNN_denoise_Conv' + str(i), nn.Conv2d(128, 128, kernel_size=(1, 1)))
                self.CNN_denoise.add_module('CNN_denoise_Act' + str(i), nn.LeakyReLU())

        self.CNN_Branch = nn.Sequential()
        for i in range(layers_count):
            if i<layers_count-1:
                self.CNN_Branch.add_module('CNN_Branch'+str(i), SSConv(128, 128,kernel_size=3))
                # self.CNN_Branch.add_module('Drop_Branch'+str(i), nn.Dropout(0.2))
            else:
                self.CNN_Branch.add_module('CNN_Branch' + str(i), SSConv(128, self.out_channel, kernel_size=5))   # 添加了两个注意力模块和卷积模块

        self.linear1 = nn.Linear(64, 64)
        self.act1 = nn.LeakyReLU()
        self.bn1 = nn.BatchNorm1d(64)

        self.Softmax_linear =nn.Sequential(nn.Linear(64, self.out_channel))

    def forward(self, x: torch.Tensor):
        (h, w, c) = x.shape
        noise = self.CNN_denoise(torch.unsqueeze(x.permute([2, 0, 1]), 0))
        noise =torch.squeeze(noise, 0).permute([1, 2, 0])


        CNN_result = self.CNN_Branch(torch.unsqueeze(noise.permute([2, 0, 1]), 0))
        return CNN_result

class CNN_de(nn.Module):
    def __init__(self, in_changel: int):
        super(CNN_de, self).__init__()
        self.channel = in_changel

        layers_count=2


        self.WH = 0
        self.M = 2
        self.CNN_denoise = nn.Sequential()
        for i in range(layers_count):
            if i == 0:
                self.CNN_denoise.add_module('CNN_denoise_BN'+str(i),nn.BatchNorm2d(self.channel))
                self.CNN_denoise.add_module('CNN_denoise_Conv'+str(i),nn.Conv2d(self.channel, 64, kernel_size=(1, 1)))
                self.CNN_denoise.add_module('CNN_denoise_Act'+str(i),nn.LeakyReLU())
            else:
                self.CNN_denoise.add_module('CNN_denoise_BN'+str(i),nn.BatchNorm2d(64),)
                self.CNN_denoise.add_module('CNN_denoise_Conv' + str(i), nn.Conv2d(64, 32, kernel_size=(1, 1)))
                self.CNN_denoise.add_module('CNN_denoise_Act' + str(i), nn.LeakyReLU())


    def forward(self, x: torch.Tensor):
        (h, w, c) = x.shape
        noise = self.CNN_denoise(torch.unsqueeze(x.permute([2, 0, 1]), 0))
        noise =torch.squeeze(noise, 0).permute([1, 2, 0])
        return noise