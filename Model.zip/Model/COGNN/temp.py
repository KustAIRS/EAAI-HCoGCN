from torch import Tensor, nn
from torch_geometric.typing import Adj
from torch.nn import Module, ModuleList

from Model.COGNN.classes import GumbelArgs


class TempSoftPlus(Module):
    def __init__(self, gumbel_args: GumbelArgs, env_dim: int):
        super(TempSoftPlus, self).__init__()
        model_list =\
            gumbel_args.temp_model_type.get_component_list(in_dim=env_dim, hidden_dim=env_dim, out_dim=1, num_layers=1,
                                                           bias=False, edges_required=False,
                                                           gin_mlp_func=gumbel_args.gin_mlp_func)
        self.linear_model = ModuleList(model_list)
        self.softplus = nn.Softplus(beta=1)  # 可用于将得到的（如果是负数或者是0）温度参数映射为正数，确保温度参数合法
        self.tau0 = gumbel_args.tau0

    def forward(self, graph, edge_attr: Tensor):
        x = graph.x
        edge_index = graph.edge_index
        x = self.linear_model[0](x=x, edge_index=edge_index,edge_attr = edge_attr) # 线性层的输出维度是 1
        x = self.softplus(x) + self.tau0
        temp = x.pow_(-1) # 求倒数
        return temp.masked_fill_(temp == float('inf'), 0.) # 如果计算出的温度为无穷大（如某些数值非常小），将其替换为 0，避免在后续计算中出现无效数值
